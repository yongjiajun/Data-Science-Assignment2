Jia Jun Yong (s3688090)
Vincent Hong Wei Heng (s3643760)

Just open the notebook. Dataset is located in data/, don't have to move it.